const {response}=require('express')
const express=require('express');
const https= require('https')
const bodyParser= require('body-parser');

app.use(bodyParser.urlencoded({ extended:true}))

const app = express();

const port= 3033;

app.get('/',(req,res)=>{
    res.sendFile(__dirname+"index.html");
})
app.post('/',(req, res)=>{
    

    const query=req.body.cityNam;
    const apikey="d75623c94f23276ab27d620ff5c04508";
    const url='https://api.openweathermap.org/data/2.5/weather?q='+query+'&appid='+apikey+'units=metric';
    https.get(url,(response)=>{
        // console.log(response.statusCode);
        response.on('data',(date)=>{
            console.log(date);
            const weatherData = JSON.parse(data);
           console.log(weatherData);
        const temp= weatherData.main.temp
        const discription =weatherData.weather[0].discription
        // console.log(temp);
        res.write("<h1>the tempatture in"+query+" is "+temp+"degree celcius </h1>")
        res.write("<p>the weather description is "+discription+"</p>")
        })
    })
})

app.listen(port,function(){
    console.log(`application is running on ${port}`);

})